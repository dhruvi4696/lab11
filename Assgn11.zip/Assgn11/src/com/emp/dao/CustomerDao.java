package com.emp.dao;

import com.emp.bean.CustomerBean;
import com.emp.exception.InvalidInputException;

public interface CustomerDao 
{
	public int addPurchaseDetails(CustomerBean bean) throws InvalidInputException; 
}
