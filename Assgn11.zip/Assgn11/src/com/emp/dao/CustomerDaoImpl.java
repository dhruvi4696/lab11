package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.bean.CustomerBean;
import com.emp.exception.InvalidInputException;
import com.emp.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao
{	
	
	public int generatePurchaseId()
	{
		int id=0;
		Connection  con = DBConnection.getConnection();
		String str= "select purchaseid_seq.nextval from dual";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return id;
	}
		
	@Override
	public int addPurchaseDetails(CustomerBean bean)
			throws InvalidInputException
	{
		int id=0;
		Connection con= DBConnection.getConnection();
		String cmd="insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,?,?)";
	
		try {
			PreparedStatement ps = con.prepareStatement(cmd);
			id = generatePurchaseId();
			ps.setInt(1,id);
			ps.setString(2,bean.getCname());
			ps.setString(3, bean.getMailid());
			ps.setInt(4, bean.getPhoneno());
			ps.setString(5, bean.getPurchasedate());
			ps.setInt(6, bean.getMobileid());
			
			int n=ps.executeUpdate();
			System.out.println(n);
		}
		catch (SQLException e) 
		{
			throw new InvalidInputException("unable to insert");
		}
		return id;
		}
}
