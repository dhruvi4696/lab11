package com.emp.bean;

public class MobileBean
{
	private int mobileid;
	private String name;
	private int price;
	private int quantity;
	
	@Override
	public String toString() {
		return "MobileBean [mobileid=" + mobileid + ", name=" + name
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}	
}
