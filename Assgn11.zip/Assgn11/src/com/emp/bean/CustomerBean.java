package com.emp.bean;

public class CustomerBean 
{
	private int purchaseid;
	private String cname;
	private String mailid;
	private int phoneno;
	private String purchasedate;
	private int mobileid;
	
	public CustomerBean() { }
	
	public CustomerBean(int purchaseid, String cname, String mailid,
			int phoneno, String purchasedate, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
		this.mobileid = mobileid;
	}
	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public int getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
	}

	public String getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}	
}
