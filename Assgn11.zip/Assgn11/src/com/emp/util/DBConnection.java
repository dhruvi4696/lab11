/*package com.emp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection
{
	public DBConnection(){
	}
	
	public static Connection getConnection()
	{	
		Connection con=null;
	
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver register success");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user ="system";
			String pass="orcl11g";
			
			con=DriverManager.getConnection(url, user, pass);
			System.out.println("connection success");
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		return con;
	}
}
*/
package com.emp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection
{
	public DBConnection(){
	}
	
	public static Connection getConnection()
	{
		Connection con=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user ="system";
		String pass="orcl11g";

		try
		{
			con=DriverManager.getConnection(url, user, pass);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
}
