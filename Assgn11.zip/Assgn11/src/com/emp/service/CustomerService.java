package com.emp.service;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.exception.InvalidInputException;

public interface CustomerService 
{
	public int addPurchaseDetails(CustomerBean bean) throws InvalidInputException;
}
