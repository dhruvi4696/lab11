package com.emp.service;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.dao.CustomerDao;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.InvalidInputException;

public class CustomerServiceImpl implements CustomerService
{
	private CustomerDao customerdao = new CustomerDaoImpl();

	@Override
	public int addPurchaseDetails(CustomerBean bean)
			throws InvalidInputException 
	{
		int id =customerdao.addPurchaseDetails(bean);
		return id;
	}
}
