package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.CustomerBean;
import com.emp.exception.InvalidInputException;
import com.emp.service.CustomerService;
import com.emp.service.CustomerServiceImpl;

public class MPSApp 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter customer name: ");
		String name = sc.next();
		System.out.println("enter customer mail id: ");
		String mailid = sc.next();
		System.out.println("enter customer date: ");
		String date = sc.next();
		System.out.println("enter customer mobile no: ");
		int phoneno = sc.nextInt();
		System.out.println("enter customer mobile id: ");
		int mobileid = sc.nextInt();
		
		CustomerBean bean = new CustomerBean();
		bean.setCname(name);
		bean.setMailid(mailid);
		bean.setPurchasedate(date);
		bean.setMobileid(mobileid);
		bean.setPhoneno(phoneno);
		System.out.println(bean);
		
		CustomerService service = new CustomerServiceImpl();
		
		try 
		{
			int n = service.addPurchaseDetails(bean);
			System.out.println("employee added! id = "+n);
		} 
		catch (InvalidInputException e) 
		{	
			e.printStackTrace();
		}
	}
}